/****************************************************************************
 *  Copyright: National ICT Australia,  2007 - 2011                         *
 *  Developed at the ATP lab, Networked Systems research theme              *
 *  Author(s): Yuriy Tselishchev, Athanassios Boulis                        *
 *  This file is distributed under the terms in the attached LICENSE file.  *
 *  If you do not find this file, copies can be found by writing to:        *
 *                                                                          *
 *      NICTA, Locked Bag 9013, Alexandria, NSW 1435, Australia             *
 *      Attention:  License Inquiry.                                        *
 *                                                                          *
 ****************************************************************************/

#ifndef _STEINERMAC_H_
#define _STEINERMAC_H_

#include <omnetpp.h>
#include "VirtualMac.h"
#include "VirtualMobilityManager.h"
#include "RoutingPacket_m.h"
#include "steinerMac_m.h"


#include <random>
#include <cstdlib>
#include <cstdio>
#include <math.h>
 #include <cassert>
#include <vector>
#define V 10 //4terminal + 12candidate

#define DIST(a,b,c,d) (sqrt(pow((a - c),2) + pow((b- d), 2)))

//code for 4 terminal nodes and max. 4 steiner points: overall 8 points

//initializing the distance array
//commenting out.. march 1

float dist_array[8][8]= {{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},
{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0}};


//declaring one packet of type steiner
enum STEINER_PACKET_TYPE
{
	M_DATA
};





using namespace std;

class steinerMac: public VirtualMac
{
	/* In order to create a MAC based on VirtualMacModule, we need to define only two
	 * functions: one to handle a packet received from the layer above (routing),
	 * and one to handle a packet from the layer below (radio)
	 */

	int range;
	int max_retries;
	int max_backoff;

	int numReTries;
	int numBackoffs;

	int engagedNode;

	int rxRate;
	//initial number of vertices in the graph (all terminal nodes)
	int vertices = 4;

	
	VirtualMobilityManager * myMobilityManager;
	
	cPacket * currentPacket;

	bool stillToSendPacket;

	double leaseDuration;
	double random();
 	bool randomGenFlipper;

 	simtime_t inTime;

 	bool first_T_cycle_over = false;
 	int countTime=0;

 	
 	NodeLocation_type myLoc;
 	

//assuming 0 to 3 as terminal nodes, we have 12 chances as candidate nodes (points of intersection : manhattan)
//loc_array has location of all the 10 points in the deployment
 	int loc_array[100][2] = {{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0}
};
//locations of candidate steiner points here:
	int candidates[96][2] = {{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0}};
 	int time_frame_length=6;  // length of duty cycle.
//costing stores the cost of the MST the addition of candidate node i in the configuration
	float costing[96] = {0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,
};

//graph with max possible dimensions declared:
	
 	float graph[V][V] =
		     {{0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
		      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0},
                      {0, 0, 0, 0, 0,0, 0, 0, 0, 0}};

	float originalcost = 1000;
	float previouscost = 1000;
	int steinerpts[5] = {0,0,0,0,0};
	int iter_no = 0;
//sum is the sum of the weights of all edges of the MST, returned by the primmst method
 	float sum , sum_next;
//methods for finding out MST
 	int minKey(int key[], bool mstSet[]);
 	float printMST(int parent[], int n, float graph[V][V]);
 	float primMST(float graph[V][V]);
//calculates the most feasible steiner point addition into the deployment 
	void computecandidates();
//calculates and returns the savings wrt to addition of node j in the graph as a steiner point
 	float calculatesavings(int j);
//finds the closest point in the actual deployment to the new found steiner point. This point will be actually added to the graph.
	int closestnode(int j);
	
	void iteration(void);
 	
protected:
	void fromRadioLayer(cPacket *, double, double);
	void fromNetworkLayer(cPacket *, int);


	void startup();

};

#endif
