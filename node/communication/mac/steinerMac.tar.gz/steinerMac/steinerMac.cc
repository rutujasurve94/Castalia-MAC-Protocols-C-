#include "steinerMac.h"
#include <random>
#include <chrono>
#include <ctime>

// Prim's Minimum Spanning Tree (MST) algorithm program: for adjacency matrix representation of the graph
 
#include <iostream>
#include <limits.h>
 
// Number of vertices in the graph at any point of execution is the variable "vertices"

 
// A utility function to find the vertex with minimum key value, from
// the set of vertices not yet included in MST
int steinerMac::minKey(int key[], bool mstSet[])
{
   // Initialize min value
   int min = INT_MAX, min_index;
 
   for (int v = 0; v < vertices; v++){
     if (mstSet[v] == false && key[v] < min){
         min = key[v]; min_index = v;
 	}
}
   return min_index;
}
 
// A utility function to print the constructed MST stored in parent[]
float steinerMac::printMST(int parent[], int n, float graph[V][V])
{
	//sum will store the sum of all the edges of the MST
	sum = 0.0;
	trace()<<"vertices "<<vertices<<endl;
	trace()<<graph[vertices-1][parent[vertices-1]]<<" traced ....."<<endl;
	trace()<<"sum set to 0"<<endl;
   trace()<<"Edge Weight: "<<endl;
//t1
   for (int i = 1; i < vertices; i++){
      trace()<< parent[i]<< " -"<< i<<" "<<graph[i][parent[i]]<<endl;
	//trace()<<graph[i][parent[i]]<<endl;

	trace()<<"Between "<<loc_array[i][0] <<" "<<loc_array[i][1] <<"and"<<loc_array[parent[i]][0] <<" "<<loc_array[parent[i]][1] <<endl;
	sum = sum + graph[i][parent[i]];
	}
	trace()<<"The weight of this graph is.. "<<sum<<endl;
	return sum;
}
 

// Function to construct and print MST for a graph represented using adjacency
// matrix representation
float steinerMac::primMST(float graph[V][V])
{
     int parent[vertices]; // Array to store constructed MST
     int key[vertices];   // Key values used to pick minimum weight edge in cut


     bool mstSet[vertices];  // To represent set of vertices not yet included in MST


//test
/*
trace()<<"Last candidates dist.."<<endl;
for (int i = 0; i < vertices ; i++)
	trace()<<graph[vertices-1][i]<<endl;
*/
trace()<<"Graph is..."<<endl;



for (int i = 0; i < vertices ; i++){
for (int j = 0; j < vertices ; j++){
trace()<<graph[i][j]<<" ";
}
trace()<<endl;
}


     // Initialize all keys as INFINITE
     for (int i = 0; i < vertices; i++){
        key[i] = INT_MAX;
	 mstSet[i] = false;
	}
 //trace()<<"INTMAX is"<<INT_MAX<<endl;
     // Always include first 1st vertex in MST.
     key[0] = 0;     // Make key 0 so that this vertex is picked as first vertex
     parent[0] = -1; // First node is always root of MST
 
     // The MST will have V vertices
//test change here
     for (int count = 0; count < vertices; count++)
     {
        // Pick thd minimum key vertex from the set of vertices
        // not yet included in MST
        int u = minKey(key, mstSet);
 
        // Add the picked vertex to the MST Set
        mstSet[u] = true;
 
        // Update key value and parent index of the adjacent vertices of
        // the picked vertex. Consider only those vertices which are not yet
        // included in MST
        for (int v = 0; v < vertices; v++)
 
           // graph[u][v] is non zero only for adjacent vertices of m
           // mstSet[v] is false for vertices not yet included in MST
           // Update the key only if graph[u][v] is smaller than key[v]
          if (graph[u][v] && mstSet[v] == false && graph[u][v] <  key[v]){
             parent[v]  = u; key[v] = graph[u][v];
		}
     }
	float treecost;
 
     // print the constructed MST
     treecost =  printMST(parent, V, graph);
	return treecost;
}
 

//For storing the x and y co-ordinates of the nodes in the deployment
Define_Module(steinerMac);
struct node_Loc {
 	double locX;
 	double locY;
};


vector <node_Loc> Loc_Vec;

void steinerMac::startup()
{
	//trace()<<"In startup of Steiner!!"<<endl;
	
	myMobilityManager = check_and_cast\
						<VirtualMobilityManager *>\
						(getParentModule()->getParentModule()->\
							getSubmodule("MobilityManager"));
	myLoc = myMobilityManager->getLocation();
	
	loc_array[SELF_MAC_ADDRESS][0] = myLoc.x;
	loc_array[SELF_MAC_ADDRESS][1] = myLoc.y;


	//trace()<<"My location is "<<myLoc.x<<"and "<<myLoc.y<<endl;

	//node no. 8 traces the startup code last, hence we move to the next method on reaching node 8
	
		trace()<<"Shall now compute candidates.."<<endl;
		computecandidates();
		
	
	
}


void steinerMac::computecandidates(){
			trace()<<"In compute candidates..."<<endl;
			cModule *theSNModule;
			theSNModule = getParentModule()->getParentModule()->getParentModule();
			cModule *tmpNode;
			//loc_array extracts the x and y locations of all the nodes into the array
			for(int i =0 ;i<100;i++){
			tmpNode = theSNModule->getSubmodule("node",i);
			loc_array[i][0] = tmpNode->par("xCoor"); 
			loc_array[i][1] = tmpNode->par("yCoor");
			}
	
//this chunk can be shifted..
//this stores the absolute distances of all nodes from each other 
	for(int i=0;i<vertices;i++){
		for(int j= 0;j<vertices;j++){
			dist_array[i][j] = DIST(loc_array[i][0],loc_array[i][1],loc_array[j][0],loc_array[j][1]);
			trace()<<"Dist of "<<i<<" "<<"from "<<j<<" is "<<dist_array[i][j]<<endl;
			graph[i][j]= dist_array[i][j];
			
		}
	}
//Now that the distances have been calculated (of all the terminal nodes from each other at this stage, we can call for MST (original without a ////single steiner point 
	trace()<<"Calling the first instance of Prim-Mst.."<<endl;
	originalcost = primMST(graph);
	trace()<<"Original cost is.. "<<originalcost<<endl;
	previouscost = originalcost;
	trace()<<"Candidate steiner points are: "<<endl;
	
	for(int i=0;i<96;i++){
		for(int j=0;j<2;j++){
	candidates[i][0] = loc_array[i+4][0] ;
	candidates[i][1] = loc_array[i+4][1] ;
	trace()<<i<<". "<<candidates[i][0]<<" "<<candidates[i][1]<<endl;
	}
	}

	
//Done with tracing of candidate steienr points
	
	iteration();
	iteration();
//	iteration();

}


void steinerMac::iteration(void) {

	trace()<<"In iteration.."<<iter_no<<endl;
	

	float mincost,saving;
	mincost =1000000; 
	vertices++; //incrementing vertex count
	///*
	costing[0] = calculatesavings(0);
	costing[1] = calculatesavings(1);
	costing[2] = calculatesavings(2);
	costing[3] = calculatesavings(3);
	costing[4] = calculatesavings(4);
	costing[5] = calculatesavings(5);
	costing[6] = calculatesavings(6);
	costing[7] = calculatesavings(7);
	costing[8] = calculatesavings(8);
	costing[9] = calculatesavings(9);
	costing[10]= calculatesavings(10);
	costing[11]= calculatesavings(11);
	//*/
	costing[12] = calculatesavings(12);
	costing[13] = calculatesavings(13);
	costing[14] = calculatesavings(14);
	costing[15] = calculatesavings(15);
	costing[16] = calculatesavings(16);
	costing[17] = calculatesavings(17);
	costing[18] = calculatesavings(18);
	costing[19] = calculatesavings(19);
	costing[20]= calculatesavings(20);
	costing[21]= calculatesavings(21);


	///*
	costing[22] = calculatesavings(22);
	costing[23] = calculatesavings(23);
	costing[24] = calculatesavings(24);
	costing[25] = calculatesavings(25);
	costing[26] = calculatesavings(26);
	costing[27] = calculatesavings(27);
	costing[28] = calculatesavings(28);
	costing[29] = calculatesavings(29);
	costing[30]= calculatesavings(30);
	costing[31]= calculatesavings(31);


	costing[40] = calculatesavings(40);
	costing[41] = calculatesavings(41);
	costing[42] = calculatesavings(42);
	costing[43] = calculatesavings(43);
	costing[44] = calculatesavings(44);
	costing[45] = calculatesavings(45);
	costing[46] = calculatesavings(46);
	costing[47] = calculatesavings(47);
	costing[48] = calculatesavings(48);
	costing[49] = calculatesavings(49);
	costing[50]= calculatesavings(50);
	


	
	costing[51] = calculatesavings(51);
	costing[52] = calculatesavings(52);
	costing[53] = calculatesavings(53);
	costing[54] = calculatesavings(54);
	costing[55] = calculatesavings(55);
	costing[56] = calculatesavings(56);
	costing[57] = calculatesavings(57);
	costing[58] = calculatesavings(58);
	costing[59] = calculatesavings(59);
	costing[60]= calculatesavings(60);
	costing[61]= calculatesavings(61);


	
	costing[62] = calculatesavings(62);
	costing[63] = calculatesavings(63);
	costing[64] = calculatesavings(64);
	costing[65] = calculatesavings(65);
	costing[66] = calculatesavings(66);
	costing[67] = calculatesavings(67);
	costing[68] = calculatesavings(68);
	costing[69] = calculatesavings(69);
	costing[70]= calculatesavings(70);
	costing[71]= calculatesavings(71);


	
	costing[72] = calculatesavings(72);
	costing[73] = calculatesavings(73);
	costing[74] = calculatesavings(74);
	costing[75] = calculatesavings(75);
	costing[76] = calculatesavings(76);
	costing[77] = calculatesavings(77);
	costing[78] = calculatesavings(78);
	costing[79] = calculatesavings(79);
	costing[80]= calculatesavings(80);
	costing[81]= calculatesavings(81);


	
	costing[82] = calculatesavings(82);
	costing[83] = calculatesavings(83);
	costing[84] = calculatesavings(84);
	costing[85] = calculatesavings(85);
	costing[86] = calculatesavings(86);
	costing[87] = calculatesavings(87);
	costing[88] = calculatesavings(88);
	costing[89] = calculatesavings(89);
	costing[90]= calculatesavings(90);
	costing[91]= calculatesavings(91);
	costing[92] = calculatesavings(92);
	costing[93] = calculatesavings(93);
	costing[94] = calculatesavings(94);
	costing[95] = calculatesavings(95);
//*/

	int saver =0; 
	int exist=0;
	//saver node becomes the new steiner point, iteration no. 1

	//for(int i=0;i<96;i++){
	 for(int i=4;i<31;i++)
{
	//for(int i=12;i<21;i++){
	//test only if it saves as against the previous cost
	//? need to make a slight change here to ignore those candidates that have already been added to the graph
		if(costing[i]<previouscost){
		if(mincost>costing[i]){
			mincost = costing[i];
			saver = i;
			exist=1;
		}
		}
	}
	if(exist==0)
		trace()<<"No saving possible"<<endl;
	else
		trace()<<"Possisble saving!!"<<endl;
	//saver = 11;
	trace()<<"Saver's cost at "<<iter_no<<" is "<<costing[saver]<<" mincost is "<<mincost<<endl;
	trace()<<"Adding "<<saver<<" as saver with co-or "<<candidates[saver][0]<<" "<<candidates[saver][1]<<" "<<"as the new steiner point with net saving at "<<iter_no+1<< " iteration, wrt previous iteration's cost "<<previouscost <<" is "<<previouscost - costing[saver]<<endl; 
	previouscost = costing[saver];
	
	trace()<<"Adding the point closest to steiner point with co-ordinates "<<candidates[saver][0]<<" "<<candidates[saver][1]<<endl;

	int steinerpoint;
	iter_no++;
	trace()<<"For iteration..."<<iter_no<<"saver is "<<saver<<endl;
//t1
	//steinerpoint = closestnode(saver);
	//steinerpts[iter_no] =  steinerpoint;
	steinerpoint = saver+4;
	steinerpts[iter_no] =  steinerpoint;
		trace()<<"check..."<<loc_array[steinerpoint][0]<<" "<<loc_array[steinerpoint][1]<<endl;
	//newly added steienr point is the point closest to the candidate node
if(iter_no==1){
	for(int i=0;i<vertices-1;i++){

			//test (remove -1 everywhere)
			//change made here
			

			dist_array[i][vertices-1] = DIST(loc_array[i][0],loc_array[i][1],loc_array[steinerpoint][0],loc_array[steinerpoint][1]);
			trace()<<"Dist of terminal "<<i<<" "<<"from steienr pt "<<steinerpoint<<" is "<<dist_array[i][vertices-1]<<endl;
			dist_array[vertices-1][i]= dist_array[i][vertices-1];
			graph[vertices-1][i]= dist_array[i][vertices-1];
			graph[i][vertices-1]= dist_array[i][vertices-1];

	}

}	

			//test (remove -1 everywhere)
			//change made here
			//t1......
if(iter_no==2){

			for(int i=0;i<vertices-2;i++){

			//test (remove -1 everywhere)
			//change made here
			

			dist_array[i][vertices-1] = DIST(loc_array[i][0],loc_array[i][1],loc_array[steinerpoint][0],loc_array[steinerpoint][1]);
			trace()<<"Dist of terminal "<<i<<" "<<"from steienr pt "<<steinerpoint<<" is "<<dist_array[i][vertices-1]<<endl;
			dist_array[vertices-1][i]= dist_array[i][vertices-1];
			graph[vertices-1][i]= dist_array[i][vertices-1];
			graph[i][vertices-1]= dist_array[i][vertices-1];

	}



			dist_array[vertices-2][vertices-1] = DIST(loc_array[steinerpts[1]][0],loc_array[steinerpts[1]][1],loc_array[steinerpoint][0],loc_array[steinerpoint][1]);
			trace()<<"Dist of terminal "<<vertices-2<<" "<<"from steienr pt "<<steinerpoint<<" is "<<dist_array[vertices-2][vertices-1]<<endl;
			dist_array[vertices-1][vertices-2]= dist_array[vertices-2][vertices-1];
			graph[vertices-1][vertices-2]= dist_array[vertices-2][vertices-1];
			graph[vertices-2][vertices-1]= dist_array[vertices-2][vertices-1];

	}

	
	//new addn
	graph[vertices-1][vertices-1] = 0;
	trace()<<"Printing the tree after iteration "<<iter_no<<".."<<endl;
	
	//previouscost = primMST(graph);
	 primMST(graph);
	

}

//this returns the cost of the tree with the addition of candidate node j;
float steinerMac::calculatesavings(int j) {

	trace()<<"In calculate savings for candidate "<<j<<"calculating cadidates again..."<<endl;

		trace()<<"Value of vertices here .. "<<vertices<<endl;

	
	
//change............

if(iter_no+1==1){
	for(int i=0;i<vertices-1;i++){

			//test (remove -1 everywhere)
			//change made here
			
			trace()<<"From calculate savings.."<<endl;
			//trace()<<"candidates[j][0] "<<candidates[j][0]<<" candidates[j][0] "<<candidates[j][0]
			dist_array[i][vertices-1] = DIST(loc_array[i][0],loc_array[i][1],candidates[j][0],candidates[j][1]);
			trace()<<"Dist of terminal "<<i<<" "<<"from candidate "<<j<<" is "<<dist_array[i][vertices-1]<<endl;
			dist_array[vertices-1][i]= dist_array[i][vertices-1];
			graph[vertices-1][i]= dist_array[i][vertices-1];
			graph[i][vertices-1]= dist_array[i][vertices-1];


			

	}

}	

			//test (remove -1 everywhere)
			//change made here
			//t1......
if(iter_no+1==2){

			for(int i=0;i<vertices-2;i++){

			//test (remove -1 everywhere)
			//change made here
			

			trace()<<"From calculate savings.."<<endl;
			//trace()<<"candidates[j][0] "<<candidates[j][0]<<" candidates[j][0] "<<candidates[j][0]
			dist_array[i][vertices-1] = DIST(loc_array[i][0],loc_array[i][1],candidates[j][0],candidates[j][1]);
			trace()<<"Dist of terminal "<<i<<" "<<"from candidate "<<j<<" is "<<dist_array[i][vertices-1]<<endl;
			dist_array[vertices-1][i]= dist_array[i][vertices-1];
			graph[vertices-1][i]= dist_array[i][vertices-1];
			graph[i][vertices-1]= dist_array[i][vertices-1];

	}



			dist_array[vertices-2][vertices-1] = DIST(loc_array[steinerpts[1]][0],loc_array[steinerpts[1]][1],candidates[j][0],candidates[j][1]);
			trace()<<"Dist of terminal "<<vertices-2<<" "<<"from candidate "<<j<<" is "<<dist_array[vertices-2][vertices-1]<<endl;
			dist_array[vertices-1][vertices-2]= dist_array[vertices-2][vertices-1];
			graph[vertices-1][vertices-2]= dist_array[vertices-2][vertices-1];
			graph[vertices-2][vertices-1]= dist_array[vertices-2][vertices-1];

	}

	
	//new addn
	graph[vertices-1][vertices-1] = 0;





	

	trace()<<"Calling primmst after calculating savings wrt "<<j<< "... "<<endl;


	primMST(graph);
	trace()<<"From calculate savings.. weight.. on "<<j<<"th call "<<sum<<endl;
	//returning the cost found
	return sum;
}


int steinerMac::closestnode(int j){
	trace()<<"From closest node, candidate is "<<candidates[j][0]<<" "<<candidates[j][1]<<endl;

			float distance, temp;
			int node;
			distance = 100000.000;
			node = 1000000;
			/*
			trace()<<"TracinG...."<<endl;
			for(int i =0 ;i<10;i++){
				trace()<<loc_array[i][0]<<" "<<loc_array[i][1]<<endl;
			}

			*/
			
	//should be altered later to not include the already added vertices to the graph
	//minor alteration needed here, for including multiple iteration
	//addn
	for(int i=4;i<100;i++){
		  if(i!=steinerpts[0] && i!=steinerpts[1] && i!=steinerpts[2] && i!=steinerpts[3] && i!=steinerpts[4]){

			temp = DIST(loc_array[i][0],loc_array[i][1],candidates[j][0],candidates[j][1]);
			trace()<<loc_array[i][0]<<" "<<loc_array[i][1]<<endl;
			if(temp<distance){
				distance = temp;
				node = i;
				trace()<<"Dist of "<<i<<" "<<"from "<<j<<" is "<<temp<<endl;
			}
			}

			
			}


	//returns the node to be added as a steiener point (from the deployment)
		return node;

		}






void steinerMac::fromNetworkLayer(cPacket * pkt, int destination)
{
	trace()<<"In from network layer"<<endl; 
				
}







void steinerMac::fromRadioLayer(cPacket * pkt, double rssi, double lqi)
{
	trace()<<"In fromradiolayer!!"<<endl;
	
}




