//
// Generated file, do not edit! Created by nedtool 4.6 from src/node/communication/mac/steinerMac/steinerMac.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "steinerMac_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(SteinerMacPacket);

SteinerMacPacket::SteinerMacPacket(const char *name, int kind) : ::MacPacket(name,kind)
{
    this->type_var = 0;
    this->timeStamp_var = 0;
    this->payload_size_var = 0;
    this->testField_var = 0;
}

SteinerMacPacket::SteinerMacPacket(const SteinerMacPacket& other) : ::MacPacket(other)
{
    copy(other);
}

SteinerMacPacket::~SteinerMacPacket()
{
}

SteinerMacPacket& SteinerMacPacket::operator=(const SteinerMacPacket& other)
{
    if (this==&other) return *this;
    ::MacPacket::operator=(other);
    copy(other);
    return *this;
}

void SteinerMacPacket::copy(const SteinerMacPacket& other)
{
    this->type_var = other.type_var;
    this->timeStamp_var = other.timeStamp_var;
    this->payload_size_var = other.payload_size_var;
    this->location_var = other.location_var;
    this->testField_var = other.testField_var;
}

void SteinerMacPacket::parsimPack(cCommBuffer *b)
{
    ::MacPacket::parsimPack(b);
    doPacking(b,this->type_var);
    doPacking(b,this->timeStamp_var);
    doPacking(b,this->payload_size_var);
    doPacking(b,this->location_var);
    doPacking(b,this->testField_var);
}

void SteinerMacPacket::parsimUnpack(cCommBuffer *b)
{
    ::MacPacket::parsimUnpack(b);
    doUnpacking(b,this->type_var);
    doUnpacking(b,this->timeStamp_var);
    doUnpacking(b,this->payload_size_var);
    doUnpacking(b,this->location_var);
    doUnpacking(b,this->testField_var);
}

int SteinerMacPacket::getType() const
{
    return type_var;
}

void SteinerMacPacket::setType(int type)
{
    this->type_var = type;
}

simtime_t SteinerMacPacket::getTimeStamp() const
{
    return timeStamp_var;
}

void SteinerMacPacket::setTimeStamp(simtime_t timeStamp)
{
    this->timeStamp_var = timeStamp;
}

int SteinerMacPacket::getPayload_size() const
{
    return payload_size_var;
}

void SteinerMacPacket::setPayload_size(int payload_size)
{
    this->payload_size_var = payload_size;
}

NodeLocation_type& SteinerMacPacket::getLocation()
{
    return location_var;
}

void SteinerMacPacket::setLocation(const NodeLocation_type& location)
{
    this->location_var = location;
}

int SteinerMacPacket::getTestField() const
{
    return testField_var;
}

void SteinerMacPacket::setTestField(int testField)
{
    this->testField_var = testField;
}

class SteinerMacPacketDescriptor : public cClassDescriptor
{
  public:
    SteinerMacPacketDescriptor();
    virtual ~SteinerMacPacketDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(SteinerMacPacketDescriptor);

SteinerMacPacketDescriptor::SteinerMacPacketDescriptor() : cClassDescriptor("SteinerMacPacket", "MacPacket")
{
}

SteinerMacPacketDescriptor::~SteinerMacPacketDescriptor()
{
}

bool SteinerMacPacketDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<SteinerMacPacket *>(obj)!=NULL;
}

const char *SteinerMacPacketDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int SteinerMacPacketDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 5+basedesc->getFieldCount(object) : 5;
}

unsigned int SteinerMacPacketDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<5) ? fieldTypeFlags[field] : 0;
}

const char *SteinerMacPacketDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "type",
        "timeStamp",
        "payload_size",
        "location",
        "testField",
    };
    return (field>=0 && field<5) ? fieldNames[field] : NULL;
}

int SteinerMacPacketDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='t' && strcmp(fieldName, "type")==0) return base+0;
    if (fieldName[0]=='t' && strcmp(fieldName, "timeStamp")==0) return base+1;
    if (fieldName[0]=='p' && strcmp(fieldName, "payload_size")==0) return base+2;
    if (fieldName[0]=='l' && strcmp(fieldName, "location")==0) return base+3;
    if (fieldName[0]=='t' && strcmp(fieldName, "testField")==0) return base+4;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *SteinerMacPacketDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "simtime_t",
        "int",
        "NodeLocation_type",
        "int",
    };
    return (field>=0 && field<5) ? fieldTypeStrings[field] : NULL;
}

const char *SteinerMacPacketDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0:
            if (!strcmp(propertyname,"enum")) return "STEINER_PACKET_TYPE";
            return NULL;
        default: return NULL;
    }
}

int SteinerMacPacketDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    SteinerMacPacket *pp = (SteinerMacPacket *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string SteinerMacPacketDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    SteinerMacPacket *pp = (SteinerMacPacket *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getType());
        case 1: return double2string(pp->getTimeStamp());
        case 2: return long2string(pp->getPayload_size());
        case 3: {std::stringstream out; out << pp->getLocation(); return out.str();}
        case 4: return long2string(pp->getTestField());
        default: return "";
    }
}

bool SteinerMacPacketDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    SteinerMacPacket *pp = (SteinerMacPacket *)object; (void)pp;
    switch (field) {
        case 0: pp->setType(string2long(value)); return true;
        case 1: pp->setTimeStamp(string2double(value)); return true;
        case 2: pp->setPayload_size(string2long(value)); return true;
        case 4: pp->setTestField(string2long(value)); return true;
        default: return false;
    }
}

const char *SteinerMacPacketDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 3: return opp_typename(typeid(NodeLocation_type));
        default: return NULL;
    };
}

void *SteinerMacPacketDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    SteinerMacPacket *pp = (SteinerMacPacket *)object; (void)pp;
    switch (field) {
        case 3: return (void *)(&pp->getLocation()); break;
        default: return NULL;
    }
}


